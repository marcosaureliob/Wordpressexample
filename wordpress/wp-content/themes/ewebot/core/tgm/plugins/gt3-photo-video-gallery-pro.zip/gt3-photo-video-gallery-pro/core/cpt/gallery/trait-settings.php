<?php

use \GT3\PhotoVideoGalleryPro\Settings;
use \GT3\PhotoVideoGalleryPro\Assets;

